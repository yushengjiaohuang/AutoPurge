rm -rf /data/media/0/Android/Clear
rm -rf /data/adb/modules/Clear_Rubbish